Projet-Algo
===========
Done
